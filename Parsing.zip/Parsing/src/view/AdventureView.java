package view;
import java.util.Scanner;
// View Class
public class AdventureView {
    private Scanner scanner;

    public AdventureView() {
        this.scanner = new Scanner(System.in);
    }

    public String getPlayerName() {
        System.out.print("Enter your name: ");
        return scanner.nextLine();
    }

    public String getUserInput() {
        System.out.print("> ");
        return scanner.nextLine();
    }

    public void displayWelcomeMessage(String playerName) {
        System.out.println("Welcome, " + playerName + ", to the Haunted House Adventure!");
        System.out.println("You find yourself standing in front of a spooky old house.");
        System.out.println("Your objective is to explore the house and uncover its mysteries.");
        System.out.println("Type commands like 'look around,' 'enter kitchen,' 'inspect mirror,' etc.");
        System.out.println("To quit the game, simply type 'quit.'");
        System.out.println("Let's begin!\n");
    }

    public void displayRoomDescription(String description) {
        System.out.println(description);
    }

    public void displayItemDescription(String description) {
        System.out.println("You inspect the item: " + description);
    }

    public void displayInvalidCommand() {
        System.out.println("Invalid command. Try something else.");
    }
}
