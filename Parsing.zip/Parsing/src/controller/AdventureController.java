package controller;
import model.AdventureModel;
import view.AdventureView;
// Controller Class
public class AdventureController {
    private AdventureModel model;
    private AdventureView view;

    public AdventureController(AdventureModel model, AdventureView view) {
        this.model = model;
        this.view = view;
    }

    public void startGame() {
        String playerName = view.getPlayerName();
        model = new AdventureModel(playerName);
        view.displayWelcomeMessage(playerName);

        while (!model.isGameIsOver()) {
            String userInput = view.getUserInput();
            if (userInput.equalsIgnoreCase("quit")) {
                break;
            }

            String[] inputParts = userInput.split(" ");
            if (inputParts.length >= 2) {
                String verb = inputParts[0].toLowerCase();
                String noun = inputParts[1].toLowerCase();

                switch (verb) {
                    case "look":
                        view.displayRoomDescription(model.getRoomDescription());
                        break;
                    case "enter":
                        model.moveToRoom(noun);
                        view.displayRoomDescription(model.getRoomDescription());
                        break;
                    case "inspect":
                        String itemDescription = model.inspectItem(noun);
                        view.displayItemDescription(itemDescription);
                        break;
                    case "unlock":
                        if (noun.equals("door")) {
                            model.unlockDoor();
                            view.displayRoomDescription(model.getRoomDescription());
                        } else {
                            view.displayInvalidCommand();
                        }
                        break;
                    default:
                        view.displayInvalidCommand();
                }
            } else {
                view.displayInvalidCommand();
            }
        }

        System.out.println("Thank you for playing! The game has ended.");
    }
}