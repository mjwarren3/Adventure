package model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
    // Model Class
    public class AdventureModel {
        private String playerName;
        private String currentLocation;
        private List<String> inventory;
        private Map<String, String> gameWorld;
        private boolean gameIsOver;

        public AdventureModel(String playerName) {
            this.playerName = playerName;
            this.currentLocation = "Foyer";
            this.inventory = new ArrayList<>();
            this.gameIsOver = false;
            initializeGameWorld();
        }

        private void initializeGameWorld() {
            // Define the game world with rooms and descriptions.
            gameWorld = new HashMap<>();
            gameWorld.put("foyer", "You are in the foyer of a spooky old house.");
            gameWorld.put("kitchen", "You've entered the kitchen. It's filled with cobwebs.");
            gameWorld.put("library", "The library is dimly lit with old, dusty books.");
            // Add more rooms and descriptions as needed.

            // Populate game world with items and their descriptions.
            gameWorld.put("key", "A rusty old key.");
            gameWorld.put("candle", "A half-burnt candle.");
            gameWorld.put("mirror", "A dusty mirror with a cracked frame.");
            gameWorld.put("spider", "A creepy spider crawling on the wall.");
            // Add more items and descriptions as needed.
        }

        public String getPlayerName() {
            return playerName;
        }

        public String getCurrentLocation() {
            return currentLocation;
        }

        public String getRoomDescription() {
            return gameWorld.get(currentLocation);
        }

        public void moveToRoom(String roomName) {
            if (gameWorld.containsKey(roomName)) {
                currentLocation = roomName;
            }
        }

        public List<String> getInventory() {
            return inventory;
        }

        public boolean isGameIsOver() {
            return gameIsOver;
        }

        public void setGameIsOver(boolean gameIsOver) {
            this.gameIsOver = gameIsOver;
        }

        public String inspectItem(String itemName) {
            // Implement logic to inspect items in the room.
            return gameWorld.get(itemName);
        }

        public boolean isDoorLocked() {
            // Implement a game-specific condition to check if the door is locked.
            return currentLocation.equals("Library") && inventory.contains("key");
        }

        public void unlockDoor() {
            // Implement unlocking the door if the conditions are met.
            if (isDoorLocked()) {
                gameWorld.put("Library", "The library door is unlocked.");
            }
        }
    }
